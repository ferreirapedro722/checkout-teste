<?php
return [
    'secret_key' => '',
    'db_username' => 'demoUser',
    'db_password' => 'demoPass',
    'dsn' => 'mysql:host=mysql;dbname=demo;charset=utf8',
];
